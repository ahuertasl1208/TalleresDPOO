import java.io.*;
import org.json.*;
import uniandes.dpoo.aerolinea.modelo.*;

public class PersistenciaAerolineaJson implements IPersistenciaAerolinea
{
	


}