package uniandes.dpoo.aerolinea.modelo;

import java.util.ArrayList;

public class Vuelo {
	
	private Avion avion;
	private Ruta ruta;
	private String fecha;
	
	
	
	public Vuelo (Ruta ruta, String fecha, Avion avion) {
		this.ruta = ruta;
		this.fecha = fecha;
		this.avion = avion;
	}
	
	public Ruta getRuta() {
		return this.ruta;
	}
	
	public Avion getAvion() {
		return this.avion;
	}
	
	public String getFecha() {
		return this.fecha;
	}
	
	
	public Collection<Tiquete> getTiquetes () {
		List<Tiquete> tiquetes = new ArrayList<>();
	    for (Tiquete t : Aerolinea.getTiquetes()) {
	        if (t.getVuelo().equals(this)) {
	            tiquetes.add(t);
	        }
	    }
	    return tiquetes;
	}
	
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) {
		
	}
	
	public boolean equals(Object obj) {
		
	}

}
