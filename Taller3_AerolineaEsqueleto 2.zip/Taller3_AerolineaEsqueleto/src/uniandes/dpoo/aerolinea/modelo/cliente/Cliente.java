package uniandes.dpoo.aerolinea.modelo.cliente;

import uniandes.dpoo.aerolinea.modelo.Vuelo;

public abstract class Cliente {
	
	public Cliente() {
		
	}
	
	public abstract String getTipoCliente();
	public abstract String getIdentificador();
	
	public int calcularValorTotalTiquetes() {
		return 0;
		
	}
	
	public void usarTiquetes(Vuelo vuelo) {
		
	}
	
	

}
